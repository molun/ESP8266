#ifndef _GUARD_H_WEB_SERVER_H_
#define _GUARD_H_WEB_SERVER_H_

void web_setup(void);
void web_loop(void);

#endif

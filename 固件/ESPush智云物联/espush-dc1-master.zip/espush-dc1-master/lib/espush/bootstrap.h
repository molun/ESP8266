#ifndef _GUARD_H_BOOTSTRAP_H_
#define _GUARD_H_BOOTSTRAP_H_

#include <Arduino.h>
int get_bootstrap_result(String* address, int* port, bool* tls);

#endif

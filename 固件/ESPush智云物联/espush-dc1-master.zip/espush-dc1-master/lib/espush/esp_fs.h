#ifndef _GUARD_H_FILESYSTEM_H_
#define _GUARD_H_FILESYSTEM_H_

int esp_fs_init(void);
void esp_fs_close(void);

#endif

#include <Arduino.h>
#include "drv.h"
#include "board.h"
#include "smemory.h"


/*
map1:
D3-5, D2-6, D1-7, D0-8
0-14, 4-12, 5-13, 16-15
*/


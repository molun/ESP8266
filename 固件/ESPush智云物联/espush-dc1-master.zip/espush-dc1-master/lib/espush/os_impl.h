#ifndef _GUARD_H_OS_IMPL_H_
#define _GUARD_H_OS_IMPL_H_

const char* get_imei(void);
void show_imei(void);
int getRSSI(void);

#endif

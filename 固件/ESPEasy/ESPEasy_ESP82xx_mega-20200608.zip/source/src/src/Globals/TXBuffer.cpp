#include "../Globals/TXBuffer.h"

#include "../DataStructs/Web_StreamingBuffer.h"


Web_StreamingBuffer TXBuffer;
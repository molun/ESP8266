#include "../Globals/ESPEasy_time.h"

ESPEasy_time node_time;
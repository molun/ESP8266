#ifndef GLOBALS_CACHE_H
#define GLOBALS_CACHE_H

void clearAllCaches();

struct Caches;
extern Caches Cache;

#endif // GLOBALS_CACHE_H
#include "../Globals/ExtraTaskSettings.h"


// TODO TD-er: Move fuctions to manage the ExtraTaskSettings cache to this file.

ExtraTaskSettingsStruct ExtraTaskSettings;
#include "ESPEasy_common.h"


String getUnknownString() { return F("Unknown"); }

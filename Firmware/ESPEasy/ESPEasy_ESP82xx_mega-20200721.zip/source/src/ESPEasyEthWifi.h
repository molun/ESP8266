#ifdef HAS_ETHERNET
#ifndef ESPEASY_WTH_WIFI_H_
#define ESPEASY_WTH_WIFI_H_

#ifndef WIFI
#define WIFI        0
#endif

#ifndef ETHERNET
#define ETHERNET    1
#endif

#endif // ESPEASY_WTH_WIFI_H_
#endif // HAS_ETHERNET
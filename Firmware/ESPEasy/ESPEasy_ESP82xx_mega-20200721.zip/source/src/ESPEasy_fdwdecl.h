#ifndef ESPEASY_FWD_DECL_H
#define ESPEASY_FWD_DECL_H

#include "ESPEasy_common.h"
#include "src/DataStructs/SettingsType.h"
#include "src/DataStructs/ESPEasy_EventStruct.h"

#include "src/Globals/CPlugins.h"

// FIXME TD-er: This header file should only be included from .ino or .cpp files
// This is only needed until the classes that need these can include the appropriate .h files to have these forward declared.




#if defined(ESP8266)

//  #include <lwip/init.h>
  # include <ESP8266WiFi.h>
  # include <ESP8266WebServer.h>
#endif // if defined(ESP8266)
#if defined(ESP32)
  # include <WiFi.h>
  # include <WebServer.h>
#endif // if defined(ESP32)

#include "I2CTypes.h"
#include "I2Cdev.h"

#include <FS.h>

#include <WiFiUdp.h>


void     statusLED(bool traffic);
void     backgroundtasks();
uint32_t getCurrentFreeStack();
uint32_t getFreeStackWatermark();


/*
struct ControllerSettingsStruct;
String   getUnknownString();
void     scheduleNextDelayQueue(unsigned long id,
                                unsigned long nextTime);
bool     canYield();
*/


void     serialHelper_getGpioNames(struct EventStruct *event,
                                   bool                rxOptional = false,
                                   bool                txOptional = false);
/*
fs::File tryOpenFile(const String& fname,
                     const String& mode);
*/


bool     resolveHostByName(const char *aHostname,
                           IPAddress & aResult);

bool     connectClient(WiFiClient& client,
                       const char *hostname,
                       uint16_t    port);

bool     connectClient(WiFiClient& client,
                       IPAddress   ip,
                       uint16_t    port);

bool   useStaticIP();
String getWifiModeString(WiFiMode_t wifimode);
bool   NetworkConnected(uint32_t timeout_ms);
bool   NetworkConnected();
bool   hostReachable(const IPAddress& ip);
bool   hostReachable(const String& hostname);
void   updateUDPport();


bool     I2C_read_bytes(uint8_t        i2caddr,
                        I2Cdata_bytes& data);
bool     I2C_write8_reg(uint8_t i2caddr,
                        byte    reg,
                        byte    value);
uint8_t  I2C_read8_reg(uint8_t i2caddr,
                       byte    reg,
                       bool   *is_ok = NULL);
uint16_t I2C_read16_reg(uint8_t i2caddr,
                        byte    reg);
int32_t  I2C_read24_reg(uint8_t i2caddr,
                        byte    reg);
uint16_t I2C_read16_LE_reg(uint8_t i2caddr,
                           byte    reg);
int16_t  I2C_readS16_reg(uint8_t i2caddr,
                         byte    reg);
int16_t  I2C_readS16_LE_reg(uint8_t i2caddr,
                            byte    reg);


bool safe_strncpy(char         *dest,
                  const String& source,
                  size_t        max_size);
bool safe_strncpy(char       *dest,
                  const char *source,
                  size_t      max_size);


void setIntervalTimer(unsigned long id);
void rulesProcessing(String& event);
void schedule_notification_event_timer(byte NotificationProtocolIndex, byte Function, struct EventStruct *event);

#ifdef USES_MQTT

// void runPeriodicalMQTT();
// void updateMQTTclient_connected();
//controllerIndex_t firstEnabledMQTT_ControllerIndex();
String getMQTT_state();
void callback(char        *c_topic,
              byte        *b_payload,
              unsigned int length);
//void MQTTDisconnect();
//bool MQTTConnect(controllerIndex_t controller_idx);
bool MQTTCheck(controllerIndex_t controller_idx);
//bool MQTT_queueFull(controllerIndex_t controller_idx);
bool MQTTpublish(controllerIndex_t controller_idx, const char *topic, const char *payload, bool retained);
#endif // ifdef USES_MQTT

void flushAndDisconnectAllClients();
bool saveUserVarToRTC();

// Used in src/Commands/*
void process_serialWriteBuffer();
void serialPrintln(const String& text);
void serialPrintln();



float getCPUload();
int getLoopCountPerSec();
void serialPrint(const String& text);
void setLogLevelFor(byte destination, byte logLevel);
uint16_t getPortFromKey(uint32_t key);

void initRTC();
boolean saveToRTC();

bool setControllerEnableStatus(controllerIndex_t controllerIndex, bool enabled);
bool setTaskEnableStatus(taskIndex_t taskIndex, bool enabled);
void taskClear(taskIndex_t taskIndex, bool save);
void SensorSendTask(taskIndex_t TaskIndex);
bool remoteConfig(struct EventStruct *event, const String& string);

String getTaskDeviceName(taskIndex_t TaskIndex);

String getControllerParameterInternalName(protocolIndex_t ProtocolIndex, ControllerSettingsStruct::VarType parameterIdx);
void addControllerParameterForm(const ControllerSettingsStruct& ControllerSettings, controllerIndex_t controllerindex, ControllerSettingsStruct::VarType varType);
void saveControllerParameterForm(ControllerSettingsStruct& ControllerSettings, controllerIndex_t controllerindex, ControllerSettingsStruct::VarType varType);

void set_mDNS();
bool allocatedOnStack(const void* address);

uint32_t createKey(uint16_t pluginNumber, uint16_t portNumber);

void sendGratuitousARP();
bool processNextEvent();
void rulesTimers();
void delayedReboot(int rebootDelay);
void sendSysInfoUDP(byte repeats);
void refreshNodeList();
void SSDP_update();


String parseTemplate(String& tmpString);
String parseTemplate(String& tmpString, bool useURLencode);
void parseCommandString(struct EventStruct *event, const String& string);

/*
String parseString(const String& string, byte indexFind);
String parseStringKeepCase(const String& string, byte indexFind);
String parseStringToEnd(const String& string, byte indexFind);
String parseStringToEndKeepCase(const String& string, byte indexFind);
String tolerantParseStringKeepCase(const String& string, byte indexFind);
*/

int parseCommandArgumentInt(const String& string, unsigned int argc);
taskIndex_t parseCommandArgumentTaskIndex(const String& string, unsigned int argc);

String describeAllowedIPrange();
void clearAccessBlock();
String rulesProcessingFile(const String& fileName, String& event);
int Calculate(const char *input, float* result);
bool SourceNeedsStatusUpdate(EventValueSource::Enum eventSource);
void SendStatus(EventValueSource::Enum source, const String& status);
//bool ExecuteCommand(taskIndex_t taskIndex, EventValueSource::Enum source, const char *Line, bool tryPlugin, bool tryInternal, bool tryRemoteConfig);

//void WifiScan(bool async, bool quick = false);
//void WifiScan();
//void WifiDisconnect();
//void setAP(bool enable);
//void setSTA(bool enable);

// Used for Networking with Wifi or Ethernet
#include "ESPEasyEthWifi.h"
#include "ESPEasyNetwork.h"
//void WiFiConnectRelaxed();
//bool WiFiConnected();

#include "src/Globals/ESPEasyWiFiEvent.h"

//void setWifiMode(WiFiMode_t wifimode);

unsigned long FreeMem(void);
void ResetFactory();
void reboot();
void SendUDPCommand(byte destUnit, const char *data, byte dataLength);
bool hasIPaddr();

//#include <FS.h>
//void printDirectory(File dir, int numTabs);

void delayBackground(unsigned long dsdelay);

//implemented in Scheduler.ino
//void setIntervalTimerOverride(unsigned long id, unsigned long msecFromNow);
//void sendGratuitousARP_now();


byte PluginCall(byte Function, struct EventStruct *event, String& str);
bool beginWiFiUDP_randomPort(WiFiUDP& udp);

#endif // ESPEASY_FWD_DECL_H

#include "EventQueue.h"

std::list<EventStructCommandWrapper> ScheduledEventQueue;


EventQueueStruct eventQueue;
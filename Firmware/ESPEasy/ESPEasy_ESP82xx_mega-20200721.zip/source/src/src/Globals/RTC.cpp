#include "../Globals/RTC.h"

#include "../DataStructs/RTCStruct.h"


RTCStruct RTC;


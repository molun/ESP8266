#include "../Globals/Protocol.h"

ProtocolVector Protocol;
int protocolCount = -1;

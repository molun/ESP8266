#include "SystemTimers.h"

std::map<unsigned long, systemTimerStruct> systemTimers;
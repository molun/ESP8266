#ifndef GLOBALS_SETTINGS_H
#define GLOBALS_SETTINGS_H

#include "../DataStructs/SettingsStruct.h"

// include the source file since it is a template class.
#include "../DataStructs/SettingsStruct.cpp"

extern SettingsStruct Settings;


#endif // GLOBALS_SETTINGS_H

#ifndef GLOBALS_RESET_FACTORY_DEFAULT_PREF_H
#define GLOBALS_RESET_FACTORY_DEFAULT_PREF_H

#include "../DataStructs/FactoryDefaultPref.h"

extern ResetFactoryDefaultPreference_struct ResetFactoryDefaultPreference;

#endif // GLOBALS_RESET_FACTORY_DEFAULT_PREF_H
#ifndef COMMAND_I2C_H
#define COMMAND_I2C_H

class String;

String Command_i2c_Scanner(struct EventStruct *event, const char* Line);

#endif // COMMAND_I2C_H

#include "../DataStructs/Caches.h"

void Caches::clearAllCaches()
{
  taskIndexName.clear();
  taskIndexValueName.clear();


}
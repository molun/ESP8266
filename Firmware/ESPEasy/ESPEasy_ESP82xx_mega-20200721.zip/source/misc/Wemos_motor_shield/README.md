# wemos_motor_shield
Alternative firmware for Wemos Motor Shield

Binary built from [pbugalski/wemos_motor_shield](https://github.com/pbugalski/wemos_motor_shield)
See also the [Wiki - WemosMotorshield](https://www.letscontrolit.com/wiki/index.php?title=WemosMotorshield) for more information.
---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

### Missing feature
See issue #1010 and note that we reserve the right to close feature requests if the originating poster is not proposing to resource the development him or herself.

### Justification
Tell us why you would like to see this feature added.

### Workarounds
Are there any workarounds you currently have in place because the feature is missing?

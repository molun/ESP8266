/*
** NodeMCU Lua 5.1 main initiator and comand interpreter
** See Copyright Notice in lua.h
*/
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "llimits.h"
#define LUA_VERSION_51
#include "os_type.h"
#include "../lua53/lua.c"

